<?php
require 'funtion.php';

if (!isset($_SESSION['login'])) {
} else {
    header('location:index.php');
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Login</title>
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body>
    <div id="layoutAuthentication">
        <div id="layoutAuthentication_content">
            <main>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-5">
                            <div class="card shadow-lg border-0 rounded-lg mt-5">
                                <div class="card-header">
                                    <h3 class="text-center font-weight-light my-4">User Kasir</h3>
                                </div>
                                <div class="card-body">
                                    <style>
                                        body {
                                            font-family: Arial, sans-serif;
                                            background-image: url(assets/img/logo2.png);
                                            background-size: cover;
                                            justify-content: center;
                                            align-items: center;

                                            margin-top: 15vh;

                                        }

                                        form {
                                            display: flex;
                                            flex-direction: column;
                                        }


                                        button[type="submit"] {
                                            padding: 10px;
                                            background-color: #00FF00;
                                            color: #fff;
                                            border: none;
                                            border-radius: 3px;
                                            cursor: pointer;
                                        }

                                        button[type="submit"]:hover {
                                            background-color: #777;
                                        }
                                    </style>

                                    <form method="post">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputEmail" name="username" type="text" placeholder="enter username" required />
                                            <label class="inputEmail">username</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="inputPassword" name="password" type="password" placeholder="enter Password" required />
                                            <label class="inputPassword">Password</label>
                                        </div>
                                        <button type="submit" name="login" class="btn btn-primary">Login</button>
                                </div>
                                </form>


                            </div>

                        </div>
                    </div>
                </div>
            </main>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
            <script src="js/scripts.js"></script>
</body>

</html>